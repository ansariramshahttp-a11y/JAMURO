
import Link from 'next/link';

export default function Header(){
  return (
    <header className="sticky top-0 z-40 border-b bg-white/80 backdrop-blur">
      <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold">Jamura</Link>
        <nav className="flex items-center gap-4">
          <Link href="/designer" className="hover:underline">Design</Link>
          <Link href="/catalog" className="hover:underline">Templates</Link>
          <Link href="/cart" className="hover:underline">Cart</Link>
          <Link href="/admin" className="hover:underline">Admin</Link>
        </nav>
      </div>
    </header>
  )
}
