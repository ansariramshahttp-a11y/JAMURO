
'use client';
import { useEffect, useRef, useState } from 'react';
import { fabric } from 'fabric';

export default function TShirtDesigner({ onChange }: { onChange?: (dataUrl: string) => void }){
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [canvas, setCanvas] = useState<fabric.Canvas | null>(null);

  useEffect(()=>{
    if(!canvasRef.current) return;
    const c = new fabric.Canvas(canvasRef.current, { backgroundColor: '#f5f5f5' });
    const shirt = new fabric.Rect({ width: 260, height: 320, rx: 20, ry: 20, fill: 'white', left: 70, top: 20, selectable:false});
    c.add(shirt);
    setCanvas(c);
    return () => c.dispose();
  },[]);

  function addText(){
    if(!canvas) return;
    const text = new fabric.IText('Your text', { left: 120, top: 100, fill: '#111', fontFamily: 'Arial', fontSize: 24 });
    canvas.add(text).setActiveObject(text);
    canvas.requestRenderAll();
  }
  function addImage(file: File){
    if(!canvas) return;
    const reader = new FileReader();
    reader.onload = () => {
      fabric.Image.fromURL(reader.result as string, img => {
        img.scaleToWidth(180);
        img.set({ left: 110, top: 120 });
        canvas.add(img);
        canvas.requestRenderAll();
      });
    };
    reader.readAsDataURL(file);
  }
  function exportPNG(){
    if(!canvas) return;
    const dataUrl = canvas.toDataURL({ format: 'png' });
    onChange?.(dataUrl);
    const a = document.createElement('a');
    a.href = dataUrl; a.download = 'design.png'; a.click();
  }

  return (
    <div className="rounded-2xl border p-4">
      <div className="flex items-start gap-6">
        <canvas ref={canvasRef} width={400} height={380} className="rounded-lg border" />
        <div className="w-64 space-y-3">
          <div className="text-lg font-semibold">Design Tools</div>
          <button onClick={addText} className="w-full rounded-xl border px-3 py-2">Add Text</button>
          <label className="w-full rounded-xl border px-3 py-2 block text-center cursor-pointer">
            Upload Image
            <input type="file" accept="image/*" className="hidden" onChange={e=> e.target.files && addImage(e.target.files[0])} />
          </label>
          <button onClick={exportPNG} className="w-full rounded-xl border px-3 py-2">Export PNG</button>
          <p className="text-xs text-gray-500">Drag to move / scale corners to resize • This is a simple 2D preview</p>
        </div>
      </div>
    </div>
  )
}
