
'use client';
import { useMemo } from 'react';
import { calcPrice, PriceInput } from '@/lib/pricing';

export default function PriceCalculator(props: { input: PriceInput }){
  const price = useMemo(()=>calcPrice(props.input), [props.input]);
  return (
    <div className="rounded-2xl border p-4">
      <div className="text-lg font-semibold">Real‑time Price</div>
      <div className="mt-2">Unit Price: ₹{price.unit}</div>
      <div>Subtotal ({props.input.quantity} pcs): ₹{price.subtotal}</div>
      <div>Delivery: ₹{price.delivery}</div>
      <div className="font-bold text-xl mt-1">Total: ₹{price.total}</div>
    </div>
  )
}
