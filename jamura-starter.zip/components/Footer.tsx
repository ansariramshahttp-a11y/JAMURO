
export default function Footer(){
  return (
    <footer className="mt-16 border-t">
      <div className="mx-auto max-w-6xl px-4 py-10 text-sm text-gray-600">
        <div>Free delivery in 5–7 days • Proudly made with love ❤️</div>
        <div className="mt-2">© {new Date().getFullYear()} Jamura — Personalized T‑Shirts</div>
      </div>
    </footer>
  )
}
