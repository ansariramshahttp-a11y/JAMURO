
import { supabase } from '@/lib/supabase';

export default function Admin(){
  return (
    <div className="space-y-4">
      <div className="text-2xl font-bold">Admin Dashboard</div>
      <div className="rounded-2xl border p-4">Connect Supabase and list orders here.</div>
    </div>
  )
}
