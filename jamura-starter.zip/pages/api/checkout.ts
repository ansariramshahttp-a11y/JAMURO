
import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  // Stub for Razorpay order creation; implement real server-side call with your key/secret
  // For test mode, just return a mock order id.
  // In production, never expose secrets to client.
  res.status(200).json({ orderId: 'order_TEST_12345' });
}
