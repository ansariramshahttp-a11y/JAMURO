
import type { NextApiRequest, NextApiResponse } from 'next';
// Save order data to Supabase via service role key (or use Row Level Security with anon key from client)
export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if(req.method !== 'POST') return res.status(405).end();
  // TODO: Save req.body to DB
  res.status(200).json({ ok: true });
}
