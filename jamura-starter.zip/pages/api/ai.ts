
import type { NextApiRequest, NextApiResponse } from 'next';

// Placeholder route. For real AI image gen:
// - Set REPLICATE_API_TOKEN and call their model endpoint.
// - Or wire up your own HF Inference endpoint.
export default async function handler(req: NextApiRequest, res: NextApiResponse){
  const { prompt } = req.body || {};
  // Return a generated placeholder (SVG data URL), so the UI works free.
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='512' height='512'>
    <rect width='100%' height='100%' fill='#f3f4f6'/>
    <text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-size='22' fill='#111' font-family='Arial'>
      AI Placeholder: ${(prompt||'Your idea').slice(0,40)}
    </text></svg>`;
  const image = `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
  res.json({ image });
}
