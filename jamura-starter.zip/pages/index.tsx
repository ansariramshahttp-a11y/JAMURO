
import Link from 'next/link';

export default function Home(){
  return (
    <div>
      <section className="grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold leading-tight">Create Your Story on a Tee</h1>
          <p className="mt-4 text-gray-600">Upload art, generate with AI, or start from templates. Real‑time price, free delivery in 5–7 days.</p>
          <div className="mt-6 flex gap-3">
            <Link href="/designer" className="rounded-2xl px-5 py-3 border font-semibold">Start Designing</Link>
            <Link href="/catalog" className="rounded-2xl px-5 py-3 border">Browse Templates</Link>
          </div>
        </div>
        <div className="rounded-2xl border aspect-video grid place-items-center">Hero Image / Mockup</div>
      </section>

      <section className="mt-16">
        <h2 className="text-2xl font-bold">How it works</h2>
        <ol className="mt-4 grid md:grid-cols-3 gap-6 text-sm">
          <li className="rounded-2xl border p-4">1. Upload/Generate design</li>
          <li className="rounded-2xl border p-4">2. Customize tee & see price</li>
          <li className="rounded-2xl border p-4">3. Checkout — free delivery</li>
        </ol>
      </section>
    </div>
  )
}
