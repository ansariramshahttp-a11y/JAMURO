
'use client';
import { useState } from 'react';
import TShirtDesigner from '@/components/TShirtDesigner';
import PriceCalculator from '@/components/PriceCalculator';
import type { PriceInput } from '@/lib/pricing';

export default function Designer(){
  const [img, setImg] = useState<string>('');
  const [input, setInput] = useState<PriceInput>({
    baseColor: '#ffffff',
    size: 'M',
    placements: ['front'],
    printSize: 'A4',
    printType: 'dtf',
    quantity: 1,
  });

  async function generateAI(prompt: string){
    // OPTION A (Free, experimental): client-side placeholder (replace with real in-browser SD if you want)
    // OPTION B (Paid or free credits): Replicate API (set REPLICATE_API_TOKEN as env var, and create /api/ai endpoint)
    const res = await fetch('/api/ai', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ prompt })});
    const data = await res.json();
    if(data.image){ setImg(data.image); }
  }

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div>
        <TShirtDesigner onChange={setImg} />
        <div className="rounded-2xl border p-4 mt-4">
          <div className="font-semibold">AI Design Generator</div>
          <form onSubmit={async e=>{ e.preventDefault(); const f=e.target as any; await generateAI(f.prompt.value); }} className="mt-3 flex gap-2">
            <input name="prompt" placeholder="Describe your design..." className="flex-1 rounded-xl border px-3 py-2" />
            <button className="rounded-xl border px-4">Generate</button>
          </form>
          <p className="text-xs text-gray-500 mt-2">Out of the box returns a placeholder. Add your preferred model provider later for real AI images.</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="rounded-2xl border p-4">
          <div className="font-semibold mb-2">Options</div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <label className="flex items-center gap-2">Size
              <select value={input.size} onChange={e=>setInput({...input, size: e.target.value as any})} className="border rounded px-2 py-1 ml-auto">
                {['S','M','L','XL','XXL'].map(s=><option key={s}>{s}</option>)}
              </select>
            </label>
            <label className="flex items-center gap-2">Print size
              <select value={input.printSize} onChange={e=>setInput({...input, printSize: e.target.value as any})} className="border rounded px-2 py-1 ml-auto">
                {['4x4','A4','A3','A2'].map(s=><option key={s}>{s}</option>)}
              </select>
            </label>
            <label className="flex items-center gap-2">Print type
              <select value={input.printType} onChange={e=>setInput({...input, printType: e.target.value as any})} className="border rounded px-2 py-1 ml-auto">
                {['screen','dtf','puff'].map(s=><option key={s}>{s}</option>)}
              </select>
            </label>
            <label className="flex items-center gap-2">Quantity
              <input type="number" min={1} value={input.quantity} onChange={e=>setInput({...input, quantity: parseInt(e.target.value||'1')})} className="border rounded px-2 py-1 ml-auto w-24"/>
            </label>
            <fieldset className="col-span-2">
              <div className="mb-1">Placement</div>
              {['front','back','sleeve','chest'].map(p=> (
                <label key={p} className="inline-flex items-center gap-2 mr-4">
                  <input type="checkbox" checked={input.placements.includes(p as any)}
                    onChange={e=>{
                      const has = input.placements.includes(p as any);
                      const placements = has ? input.placements.filter(x=>x!==p) : [...input.placements, p as any];
                      setInput({...input, placements});
                    }}/>
                  {p}
                </label>
              ))}
            </fieldset>
          </div>
        </div>

        <PriceCalculator input={input} />

        <form method="POST" action="/api/checkout" className="rounded-2xl border p-4 space-y-2">
          <div className="font-semibold">Checkout</div>
          <input name="name" placeholder="Name" className="w-full border rounded px-3 py-2" required/>
          <input name="email" type="email" placeholder="Email" className="w-full border rounded px-3 py-2" required/>
          <input name="phone" placeholder="Phone" className="w-full border rounded px-3 py-2" required/>
          <textarea name="address" placeholder="Shipping Address" className="w-full border rounded px-3 py-2" required/>
          <button className="w-full rounded-xl border px-4 py-2 font-semibold">Pay with Razorpay</button>
          <p className="text-xs text-gray-500">Test mode by default. Enable live in /api/checkout.</p>
        </form>
      </div>
    </div>
  )
}
