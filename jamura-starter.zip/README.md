
# Jamura — AI T‑Shirt E‑commerce (Starter)

A free full‑stack starter (Next.js + Tailwind) with:
- 2D T‑shirt designer (Fabric.js)
- Real‑time price calculator
- AI generator endpoint stub (returns placeholder today; plug any model when ready)
- Razorpay checkout stub (test mode)
- Supabase integration scaffolding (auth + DB + storage)
- Pages: Home, Designer, Catalog, Cart, Admin

## Quick Start
1. **Install**
   ```bash
   pnpm i  # or npm i / yarn
   pnpm dev
   ```
2. Open http://localhost:3000

## Connect Supabase (Free)
- Create project at https://supabase.com (free tier).
- In **.env.local** add:
  ```
  NEXT_PUBLIC_SUPABASE_URL=your_url
  NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
  ```
- Create a table `orders` (id uuid default uuid_generate_v4 primary key, name text, email text, phone text, address text, config jsonb, amount int, status text default 'pending').

## Razorpay (Free to integrate)
- Use test keys in development. Create an order in `/pages/api/checkout.ts` using server key/secret.
- On client, open Razorpay checkout (docs) with returned order id.

## AI Design Generator (Free-first)
- By default `/api/ai` returns an SVG **placeholder** so your UI works 100% free.
- When you’re ready, plug a provider:
  - Replicate (SDXL / Flux / etc.): set `REPLICATE_API_TOKEN` server-side and call their model endpoint.
  - Or run an in-browser model (experimental) using `onnxruntime-web` + SD Turbo (WebGPU).

## Deploy (Free)
- Push to GitHub → Import on Vercel → set env vars → Deploy.
- Static assets are cached automatically; API routes run as serverless functions.

## Where to add business logic
- **Pricing rules:** `/lib/pricing.ts`
- **Designer tools:** `/components/TShirtDesigner.tsx`
- **Checkout & orders:** `/pages/api/checkout.ts` and `/pages/api/order.ts`
- **Admin UI:** `/pages/admin.tsx`

## Notes
- Delivery set to free (5–7 days) — you can surface this in UI banners.
- Lighthouse >90 achievable with image optimization and font loading tweaks.
