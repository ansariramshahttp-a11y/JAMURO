
export type PrintType = 'screen' | 'dtf' | 'puff';
export type Size = 'S'|'M'|'L'|'XL'|'XXL';
export type Placement = 'front'|'back'|'sleeve'|'chest';

export interface PriceInput {
  baseColor: string;
  size: Size;
  placements: Placement[];
  printSize: 'A4' | 'A3' | 'A2' | '4x4';
  printType: PrintType;
  quantity: number;
}

// Simple example pricing table; tweak values to match your sheet
const BASE_PRICE: Record<Size, number> = { S: 249, M: 259, L: 269, XL: 279, XXL: 299 };
const PRINT_TYPE_MULTIPLIER: Record<PrintType, number> = { screen: 1.0, dtf: 1.2, puff: 1.5 };
const PRINT_SIZE_ADDON: Record<PriceInput['printSize'], number> = { '4x4': 40, A4: 80, A3: 120, A2: 180 };
const PLACEMENT_ADDON: Record<Placement, number> = { front: 30, back: 30, sleeve: 20, chest: 25 };

export function calcPrice(i: PriceInput) {
  const base = BASE_PRICE[i.size];
  const placement = i.placements.reduce((s,p) => s + PLACEMENT_ADDON[p], 0);
  const sizeAddon = PRINT_SIZE_ADDON[i.printSize];
  const typeMult = PRINT_TYPE_MULTIPLIER[i.printType];
  const unit = Math.round((base + placement + sizeAddon) * typeMult);
  const subtotal = unit * i.quantity;
  const delivery = 0; // Free delivery per spec
  return { unit, subtotal, delivery, total: subtotal + delivery };
}
